<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $surname = $_POST['surname'];
  $gender = $_POST['gender'];
  $country = $_POST['country'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $message = $_POST['message'];

  // Yeni mesajı oturuma ekle
  if (!isset($_SESSION['contacts'])) {
    $_SESSION['contacts'] = [];
  }

  $newContact = [
    'name' => $name,
    'surname' => $surname,
    'gender' => $gender,
    'country' => $country,
    'email' => $email,
    'phone' => $phone,
    'message' => $message
  ];

  $_SESSION['contacts'][] = $newContact;

  header("Location: contact_list.php");
  exit();
}
?>
