<?php
session_start();
$contacts = isset($_SESSION['contacts']) ? $_SESSION['contacts'] : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Gönderilen Mesajlar</title>
</head>
<body>
  <div class="contact-list">
    <h2>Gönderilen Mesajlar</h2>
    <ul>
      <?php
      if (count($contacts) > 0) {
        foreach ($contacts as $contact) {
          echo "<li>";
          echo "<p><strong>Ad:</strong> " . htmlspecialchars($contact['name']) . "</p>";
          echo "<p><strong>Soyad:</strong> " . htmlspecialchars($contact['surname']) . "</p>";
          echo "<p><strong>Cinsiyet:</strong> " . htmlspecialchars($contact['gender']) . "</p>";
          echo "<p><strong>Ülke:</strong> " . htmlspecialchars($contact['country']) . "</p>";
          echo "<p><strong>Email:</strong> " . htmlspecialchars($contact['email']) . "</p>";
          echo "<p><strong>Telefon:</strong> " . htmlspecialchars($contact['phone']) . "</p>";
          echo "<p><strong>Mesaj:</strong> " . htmlspecialchars($contact['message']) . "</p>";
          echo "</li>";
        }
      } else {
        echo "<p>Henüz mesaj yok.</p>";
      }
      ?>
    </ul>
  </div>
</body>
</html>
